package Models;

public class EmployeeAllocate {
}
