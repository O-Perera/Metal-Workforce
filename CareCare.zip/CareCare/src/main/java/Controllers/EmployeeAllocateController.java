package Controllers;

import Views.AllocaterView.EmployeeAllocateUI;

public class EmployeeAllocateController {
    private EmployeeAllocateUI view;

    public EmployeeAllocateController(EmployeeAllocateUI view) {
        this.view = view;

        // Add any additional initialization or logic for the controller
    }
    public void handleEmployeeAllocation(String selectedEmployee, String selectedJob) {
        // Your logic for handling employee allocation goes here
    }


    // Add controller logic as needed
}
