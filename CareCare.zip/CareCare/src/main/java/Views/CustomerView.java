package Views;

import javax.swing.*;

public class CustomerView {
    private JCheckBox checkBox1;
    private JTextArea textArea1;
    private JEditorPane editorPane1;
}
