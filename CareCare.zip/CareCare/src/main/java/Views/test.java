package Views;

import javax.swing.*;

public class test {


    private JPanel panel1;
    private JButton button1;
    private JCheckBox checkBox1;


    public static void main(String[] args) {

    }
}
